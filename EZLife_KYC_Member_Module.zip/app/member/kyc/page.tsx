"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import KYCForm from "@/components/member/kyc/KYCForm";
import { supabase } from "@/lib/supabase";

type MemberContext = { authUserId: string; memberId: string; fullName: string; email: string; };

export default function MemberKycPage() {
  const router = useRouter();
  const [member, setMember] = useState<MemberContext | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.user) return router.replace("/member/login");
        const { data: profile, error } = await supabase
          .from("profiles")
          .select("member_id, full_name, email, role, status")
          .eq("auth_user_id", session.user.id)
          .single();
        if (error || !profile || profile.role !== "member" || profile.status !== "active" || !profile.member_id) {
          await supabase.auth.signOut();
          return router.replace("/member/login");
        }
        if (mounted) {
          setMember({ authUserId: session.user.id, memberId: profile.member_id, fullName: profile.full_name, email: profile.email });
          setLoading(false);
        }
      } catch (e) {
        console.error(e);
        if (mounted) setLoading(false);
        toast.error("KYC page load nahi ho saka.");
      }
    }
    void load();
    return () => { mounted = false; };
  }, [router]);

  if (loading) return <main className="flex min-h-screen items-center justify-center bg-slate-950 text-white">Loading KYC...</main>;
  if (!member) return null;

  return (
    <main className="min-h-screen bg-slate-950 px-4 py-6 text-white sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        <button onClick={() => router.push("/member/dashboard")} className="mb-6 rounded-xl border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-semibold text-slate-300">← Back to Dashboard</button>
        <KYCForm member={member} />
      </div>
    </main>
  );
}
