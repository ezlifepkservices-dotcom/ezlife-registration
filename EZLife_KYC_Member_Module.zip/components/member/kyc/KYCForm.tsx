"use client";

import { LoaderCircle, Save, Send, Upload } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { type KycDocumentType, uploadKycDocument } from "@/lib/storage";
import { supabase } from "@/lib/supabase";

type MemberContext = { authUserId: string; memberId: string; fullName: string; email: string; };
type KycRecord = { id: string; status: string; cnic_number: string | null; father_or_husband_name: string | null; date_of_birth: string | null; residential_address: string | null; city: string | null; profession: string | null; monthly_income: number | null; };

const docs: { type: KycDocumentType; label: string }[] = [
  { type: "cnic_front", label: "CNIC Front" },
  { type: "cnic_back", label: "CNIC Back" },
  { type: "selfie", label: "Selfie / Profile Photo" },
];

export default function KYCForm({ member }: { member: MemberContext }) {
  const [kyc, setKyc] = useState<KycRecord | null>(null);
  const [files, setFiles] = useState<Partial<Record<KycDocumentType, File>>>({});
  const [form, setForm] = useState({ cnic_number: "", father_or_husband_name: "", date_of_birth: "", residential_address: "", city: "", profession: "", monthly_income: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function load() {
      const { data, error } = await supabase.from("member_kyc").select("id,status,cnic_number,father_or_husband_name,date_of_birth,residential_address,city,profession,monthly_income").eq("member_id", member.memberId).limit(1);
      if (error) return toast.error(error.message);
      const current = (data?.[0] as KycRecord | undefined) ?? null;
      if (current) {
        setKyc(current);
        setForm({
          cnic_number: current.cnic_number ?? "",
          father_or_husband_name: current.father_or_husband_name ?? "",
          date_of_birth: current.date_of_birth ?? "",
          residential_address: current.residential_address ?? "",
          city: current.city ?? "",
          profession: current.profession ?? "",
          monthly_income: current.monthly_income?.toString() ?? "",
        });
      }
    }
    void load();
  }, [member.memberId]);

  function setField(name: keyof typeof form, value: string) { setForm(v => ({ ...v, [name]: value })); }

  async function save(submit: boolean) {
    if (submit && (!form.cnic_number || !form.father_or_husband_name || !form.date_of_birth || !form.residential_address || !form.city)) {
      return toast.error("Required fields complete karein.");
    }
    setSaving(true);
    try {
      const payload = {
        member_id: member.memberId,
        cnic_number: form.cnic_number || null,
        father_or_husband_name: form.father_or_husband_name || null,
        date_of_birth: form.date_of_birth || null,
        residential_address: form.residential_address || null,
        city: form.city || null,
        profession: form.profession || null,
        monthly_income: form.monthly_income ? Number(form.monthly_income) : null,
        status: submit ? "submitted" : "draft",
        submitted_at: submit ? new Date().toISOString() : null,
        updated_at: new Date().toISOString(),
      };

      let current: KycRecord;
      if (kyc) {
        const { data, error } = await supabase.from("member_kyc").update(payload).eq("id", kyc.id).select("id,status,cnic_number,father_or_husband_name,date_of_birth,residential_address,city,profession,monthly_income").single();
        if (error || !data) throw new Error(error?.message || "KYC update failed");
        current = data as KycRecord;
      } else {
        const { data, error } = await supabase.from("member_kyc").insert(payload).select("id,status,cnic_number,father_or_husband_name,date_of_birth,residential_address,city,profession,monthly_income").single();
        if (error || !data) throw new Error(error?.message || "KYC create failed");
        current = data as KycRecord;
      }
      setKyc(current);

      for (const item of docs) {
        const file = files[item.type];
        if (!file) continue;
        const filePath = await uploadKycDocument({ authUserId: member.authUserId, documentType: item.type, file });
        const { data: existing } = await supabase.from("kyc_documents").select("id,version_no").eq("kyc_id", current.id).eq("document_type", item.type).limit(1);
        if (existing?.[0]) {
          const { error } = await supabase.from("kyc_documents").update({ file_path: filePath, status: "pending", review_reason_id: null, review_comment: null, reviewed_by: null, reviewed_at: null, resubmitted_at: new Date().toISOString(), version_no: Number(existing[0].version_no || 0) + 1, updated_at: new Date().toISOString() }).eq("id", existing[0].id);
          if (error) throw new Error(error.message);
        } else {
          const { error } = await supabase.from("kyc_documents").insert({ kyc_id: current.id, member_id: member.memberId, document_type: item.type, file_path: filePath, status: "pending", version_no: 1 });
          if (error) throw new Error(error.message);
        }
      }

      toast.success(submit ? "KYC submitted for review." : "KYC draft saved.");
    } catch (e) {
      console.error(e);
      toast.error(e instanceof Error ? e.message : "KYC save nahi ho saka.");
    } finally {
      setSaving(false);
    }
  }

  const input = "mt-2 h-12 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 text-white outline-none focus:border-violet-400";

  return (
    <section className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-xl sm:p-8">
      <p className="text-xs font-bold uppercase tracking-[0.18em] text-violet-300">Member Verification</p>
      <h1 className="mt-3 text-3xl font-black">Complete Your KYC</h1>
      <p className="mt-3 text-slate-400">Save draft ya complete details ke baad submit karein.</p>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <div><label>Full Name</label><div className={`${input} flex items-center text-slate-400`}>{member.fullName}</div></div>
        <div><label>Email</label><div className={`${input} flex items-center text-slate-400`}>{member.email}</div></div>
        <div><label>CNIC Number *</label><input className={input} value={form.cnic_number} onChange={e => setField("cnic_number", e.target.value)} /></div>
        <div><label>Father / Husband Name *</label><input className={input} value={form.father_or_husband_name} onChange={e => setField("father_or_husband_name", e.target.value)} /></div>
        <div><label>Date of Birth *</label><input type="date" className={input} value={form.date_of_birth} onChange={e => setField("date_of_birth", e.target.value)} /></div>
        <div><label>City *</label><input className={input} value={form.city} onChange={e => setField("city", e.target.value)} /></div>
        <div><label>Profession</label><input className={input} value={form.profession} onChange={e => setField("profession", e.target.value)} /></div>
        <div><label>Monthly Income</label><input type="number" className={input} value={form.monthly_income} onChange={e => setField("monthly_income", e.target.value)} /></div>
      </div>

      <div className="mt-6"><label>Residential Address *</label><textarea rows={4} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-white outline-none focus:border-violet-400" value={form.residential_address} onChange={e => setField("residential_address", e.target.value)} /></div>

      <div className="mt-10 grid gap-4 lg:grid-cols-3">
        {docs.map(item => (
          <label key={item.type} className="cursor-pointer rounded-2xl border border-dashed border-slate-700 bg-slate-950 p-5 text-center hover:border-violet-400">
            <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" className="hidden" onChange={e => setFiles(v => ({ ...v, [item.type]: e.target.files?.[0] }))} />
            <Upload className="mx-auto h-6 w-6 text-violet-300" />
            <p className="mt-3 font-bold">{item.label}</p>
            <p className="mt-1 text-xs text-slate-500">{files[item.type]?.name || "Choose file"}</p>
          </label>
        ))}
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-end">
        <button onClick={() => void save(false)} disabled={saving} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-5 font-bold"><Save className="h-5 w-5" /> Save Draft</button>
        <button onClick={() => void save(true)} disabled={saving} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-violet-600 px-6 font-black"><Send className="h-5 w-5" /> {saving ? <LoaderCircle className="h-5 w-5 animate-spin" /> : "Submit KYC"}</button>
      </div>
    </section>
  );
}
